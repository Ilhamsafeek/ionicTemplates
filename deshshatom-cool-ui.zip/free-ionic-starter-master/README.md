# free-ionic-starter

I created this for testing purposes. you can download this for any purposes. You also can see this on the IONIC MARKET
[see in ionic market](http://market.ionic.io/starters/deshshatom-cool-ui)

## Installation

1. Type in terminal or cmd " git clone  https://github.com/deshatom/free-ionic-starter.git " or download this project
2. cd free-ionic-starter
3. nmp install
4. bower install
5. ionic serve

## Run in android

1. ionic platform add android
2. ionic build android
3. ionic run androi

## Run in ios (you must have mac)

1. ionic platform add ios
2. ionic build ios
3. ionic run ios


## Let me know

[see in ionic market](http://market.ionic.io/starters/deshshatom-cool-ui)
let me know if you have any question... Also add an star.. Thank you..
